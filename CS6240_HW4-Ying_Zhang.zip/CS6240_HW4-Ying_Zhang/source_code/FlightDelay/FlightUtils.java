package FlightDelay;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;

/**
 * Created by ying on 3/16/17.
 */
public class FlightUtils {
    /**
     * Check if the flight is valid
     *
     * @param flightData String
     * @return Flight if valid else null
     */
    public static Flight getValidFlight(String flightData) {
        String[] attributes = flightData.toString().split(",");
        int year = Integer.parseInt(attributes[0]);
        int month = Integer.parseInt(attributes[2]);
        // If flight is not in the time period required, return false
        if (year != Constants.YEAR) {
            return null;
        }
        //Check valid airline
        String airline = attributes[6].trim();
        if (airline == null || airline.length() == 0) {
            return null;
        }
        // Get cancelled & diverted attributes from the flight
        boolean cancelled = (int) Float.parseFloat(attributes[43]) == 1;
        boolean diverted = (int) Float.parseFloat(attributes[45]) == 1;
        // If flight has been cancelled or diverted, return
        if (cancelled || diverted) {
            return null;
        }

        String arrDelay = attributes[39];
        if (arrDelay == null || arrDelay.length() == 0) {
            return null;
        }
        int arrDelayMinutes = (int) Float.parseFloat(arrDelay);

        Flight flight = new Flight();
        flight.setAirline(new Text(airline));
        flight.setMonth(new IntWritable(month));
        flight.setArrDelayMinutes(new IntWritable(arrDelayMinutes));
        return flight;
    }
}
