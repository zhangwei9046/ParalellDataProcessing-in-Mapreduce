package FlightDelay;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

import java.io.*;


/**
 * Created by ying on 2/23/17.
 */
public class FlightDelay {

    //Mapper
    public static class FlightClassifyMapper
            extends Mapper<Object, Text, FlightKeyPair, IntWritable> {
        public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            // Get a valid flight data from value
            // Valid flight is in 2008 and not cancelled or diverted
            Flight flight = FlightUtils.getValidFlight(value.toString());
            if (flight == null) {
                return;
            }
            context.write(new FlightKeyPair(flight.getAirline().toString(), flight.getMonth().get()),
                    new IntWritable(flight.getArrDelayMinutes().get()));
        }

    }

    // Partitioner
    public static class FlightPartitioner extends
            Partitioner<FlightKeyPair, IntWritable> {

        @Override
        public int getPartition(FlightKeyPair key, IntWritable value,
                                int numPartitions) {
            return (Math.abs(key.getAirline().hashCode()) % numPartitions);
        }
    }

    //Grouping Comparator
    public static class FlightGroupComparator extends WritableComparator {

        protected FlightGroupComparator() {
            super(FlightKeyPair.class, true);
        }

        //Put the flights with the same airline into the one group
        @Override
        public int compare(WritableComparable a, WritableComparable b) {
            FlightKeyPair key1 = (FlightKeyPair) a;
            FlightKeyPair key2 = (FlightKeyPair) b;

            return (key1.getAirline().compareTo(key2.getAirline()));
        }
    }

    //Sort Comparator
    public static class FlightSortComparator extends WritableComparator {

        protected FlightSortComparator() {
            super(FlightKeyPair.class, true);
        }

        //First Sort the airline, then secondary sort on month
        @Override
        public int compare(WritableComparable a, WritableComparable b) {
            FlightKeyPair key1 = (FlightKeyPair) a;
            FlightKeyPair key2 = (FlightKeyPair) b;
            return key1.compareTo(key2);
        }
    }

    //Reducer
    public static class FlightJoinReducer extends Reducer<FlightKeyPair, IntWritable, Text, Text> {
        public void reduce(FlightKeyPair key, Iterable<IntWritable> values, Context context)
                throws IOException, InterruptedException {
            float monthDelaySum = 0;
            int monthDelayCnt = 0;
            //Initialize a array to store the calculation result of average delay for each month
            //monthDelayAvg[0] stands for the avgDelay in Month 1
            int[] monthDelayAvg = new int[12];
            int prevMonth = 1;
            for (IntWritable value : values) {
                int month = key.getMonth();
                if (month != prevMonth) {
                    // Since the key has been sorted, when switched to next month,
                    // put the calculation results into previous month.
                    monthDelayAvg[prevMonth - 1] = (int) Math.ceil(monthDelaySum / monthDelayCnt);
                    prevMonth = month;
                    monthDelaySum = 0;
                    monthDelayCnt = 0;
                }
                monthDelaySum += value.get();
                monthDelayCnt++;
            }
            monthDelayAvg[prevMonth - 1] = (int) Math.ceil(monthDelaySum / monthDelayCnt);

            //Use a StringBuilder to construct the values of 12 month for output
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 12; i++) {
                if (i > 0) {
                    sb.append(", ");
                }
                sb.append("(").append(i + 1).append(",")
                        .append(monthDelayAvg[i]).append(")");
            }

            //Emit
            context.write(new Text(key.getAirline()), new Text(sb.toString()));
        }
    }


    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();
        if (otherArgs.length != 2) {
            System.err.println("Usage: flightdelay <in> <out>");
            System.exit(2);
        }

        //Run Flight Delay Map-Reduce Job
        Job job1 = new Job(conf, "flight delay");
        job1.setJarByClass(FlightDelay.class);
        job1.setMapperClass(FlightDelay.FlightClassifyMapper.class);
        job1.setReducerClass(FlightDelay.FlightJoinReducer.class);
        //Partitioner
        job1.setPartitionerClass(FlightPartitioner.class);
        //SortComparator
        job1.setSortComparatorClass(FlightSortComparator.class);
        //GroupingComparator
        job1.setGroupingComparatorClass(FlightGroupComparator.class);
        job1.setMapOutputKeyClass(FlightKeyPair.class);
        job1.setMapOutputValueClass(IntWritable.class);
//        // Set Reducer Tasks to 10
        job1.setNumReduceTasks(10);
        FileInputFormat.addInputPath(job1, new Path(otherArgs[0]));
        FileOutputFormat.setOutputPath(job1, new Path(otherArgs[1]));
        System.exit(job1.waitForCompletion(true) ? 0 : 1);
    }
}