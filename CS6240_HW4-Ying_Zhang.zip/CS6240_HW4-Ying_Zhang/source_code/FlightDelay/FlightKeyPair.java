package FlightDelay;

import org.apache.hadoop.io.WritableComparable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

/**
 * Created by ying on 3/16/17.
 */
public class FlightKeyPair implements WritableComparable<FlightKeyPair> {
    private String airline;
    private int month;

    public FlightKeyPair() {
    }

    public FlightKeyPair(String airline, int month) {
        this.airline = airline;
        this.month = month;
    }

    public int compareTo(FlightKeyPair key) {
        int cmpAirline = this.airline.compareTo(key.airline);
        if (cmpAirline == 0) {
            return compareMonths(this.month, key.getMonth());
        }
        return cmpAirline;
    }

    private int compareMonths(int m1, int m2) {
        return ((m1 < m2) ? -1 : ((m1 > m2) ? 1 : 0));
    }

    public void write(DataOutput dataOutput) throws IOException {
        dataOutput.writeUTF(this.airline);
        dataOutput.writeInt(this.month);
    }

    public void readFields(DataInput dataInput) throws IOException {
        this.airline = dataInput.readUTF();
        this.month = dataInput.readInt();
    }

    public String getAirline() {
        return airline;
    }

    public void setAirline(String airline) {
        this.airline = airline;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        FlightKeyPair that = (FlightKeyPair) o;

        if (month != that.month) return false;
        return airline != null ? airline.equals(that.airline) : that.airline == null;

    }

    @Override
    public int hashCode() {
        int result = airline != null ? airline.hashCode() : 0;
        result = 31 * result + month;
        return result;
    }

    @Override
    public String toString() {
        return "FlightKeyPair{" +
                "airline='" + airline + '\'' +
                ", month=" + month +
                '}';
    }
}
