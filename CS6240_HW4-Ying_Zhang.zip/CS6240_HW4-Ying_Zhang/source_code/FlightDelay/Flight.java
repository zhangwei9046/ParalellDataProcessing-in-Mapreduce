package FlightDelay;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

/**
 * Created by ying on 2/24/17.
 */
public class Flight implements Writable {
    private Text airline;
    private IntWritable month;
    private IntWritable arrDelayMinutes;

    public Flight() {
        this.airline = new Text();
        this.month = new IntWritable();
        this.arrDelayMinutes = new IntWritable();
    }

    public Text getAirline() {
        return airline;
    }

    public void setAirline(Text airline) {
        this.airline = airline;
    }

    public IntWritable getArrDelayMinutes() {
        return arrDelayMinutes;
    }

    public IntWritable getMonth() {
        return month;
    }

    public void setMonth(IntWritable month) {
        this.month = month;
    }


    public void setArrDelayMinutes(IntWritable arrDelayMinutes) {
        this.arrDelayMinutes = arrDelayMinutes;
    }

    public void write(DataOutput dataOutput) throws IOException {
        airline.write(dataOutput);
        month.write(dataOutput);
        arrDelayMinutes.write(dataOutput);
    }

    public void readFields(DataInput dataInput) throws IOException {
        airline.readFields(dataInput);
        month.readFields(dataInput);
        arrDelayMinutes.readFields(dataInput);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Flight flight = (Flight) o;

        if (airline != null ? !airline.equals(flight.airline) : flight.airline != null) return false;
        if (month != null ? !month.equals(flight.month) : flight.month != null) return false;
        return arrDelayMinutes != null ? arrDelayMinutes.equals(flight.arrDelayMinutes) : flight.arrDelayMinutes == null;

    }

    @Override
    public int hashCode() {
        int result = airline != null ? airline.hashCode() : 0;
        result = 31 * result + (month != null ? month.hashCode() : 0);
        result = 31 * result + (arrDelayMinutes != null ? arrDelayMinutes.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "Flight{" +
                "airline=" + airline +
                ", month=" + month +
                ", arrDelayMinutes=" + arrDelayMinutes +
                '}';
    }
}
