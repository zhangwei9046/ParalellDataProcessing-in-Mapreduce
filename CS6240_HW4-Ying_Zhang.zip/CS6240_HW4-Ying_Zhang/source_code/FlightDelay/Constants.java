package FlightDelay;

/**
 * Created by ying on 3/16/17.
 */
public class Constants {
    // The year of interest
    public static final int YEAR = 2008;
}
