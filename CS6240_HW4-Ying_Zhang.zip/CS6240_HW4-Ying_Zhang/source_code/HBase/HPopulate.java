package HBase;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.mapreduce.TableOutputFormat;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

import au.com.bytecode.opencsv.CSVParser;

public class HPopulate {
    public static final String HBASE_TABLE_NAME = "FlightData";
    public static final String COLUMN_FAMILY = "Flight";
    public static final String COLUMN_YEAR = "year";
    public static final String COLUMN_CANCELLED = "cancelled";
    public static final String COLUMN_DELAY = "delay";

    // Mapper
    public static class HPopulateMapper extends
            Mapper<Object, Text, ImmutableBytesWritable, Writable> {
        private CSVParser csvParser;
        private HTable table;

        protected void setup(Context context) throws IOException {
            csvParser = new CSVParser(',', '"');
            Configuration config = HBaseConfiguration.create();
            table = new HTable(config, HBASE_TABLE_NAME);
            table.setAutoFlush(false);
            table.setWriteBufferSize(102400);

        }

        public void map(Object key, Text value, Context context)
                throws IOException, InterruptedException {
            // Parse the input value using csvParser
            String[] vals = csvParser.parseLine(value.toString());
            StringBuilder rowKey = new StringBuilder();
            if (vals.length == 0) {
                return;
            }
            // Construct rowKey
            rowKey.append(vals[6]).append("#");
            rowKey.append(vals[5]).append("#");
            rowKey.append(vals[10]).append("#");
            rowKey.append(vals[11]);
            //Construct record to put into Hbase
            Put put = new Put(Bytes.toBytes(rowKey.toString()));
            put.add(COLUMN_FAMILY.getBytes(), COLUMN_CANCELLED.getBytes(), ((int) Float.parseFloat(vals[41]) == 1
                    ? "1" : "0").getBytes());
            put.add(COLUMN_FAMILY.getBytes(), COLUMN_DELAY.getBytes(), String.valueOf(vals[37].isEmpty() ?
                    0f : Float.parseFloat(vals[37])).getBytes());
            put.add(COLUMN_FAMILY.getBytes(), COLUMN_YEAR.getBytes(), vals[0].getBytes());

            table.put(put);
        }

        protected void cleanup(Context context) throws IOException, InterruptedException {
            table.close();
        }
    }

    public static void main(String[] args) throws IOException, InterruptedException, ClassNotFoundException {
        Configuration conf = new Configuration();
        String[] otherArgs = new GenericOptionsParser(conf, args)
                .getRemainingArgs();
        if (otherArgs.length != 1) {
            System.err.println("Usage: H-POPULATE <in>");
            System.exit(2);
        }

        createHbaseTable();

        // Configure job
        Job job = new Job(conf, "H-Populate");
        job.setJarByClass(HPopulate.class);
        job.setMapperClass(HPopulateMapper.class);
        job.setOutputKeyClass(ImmutableBytesWritable.class);
        job.setOutputValueClass(Put.class);
        job.setOutputFormatClass(TableOutputFormat.class);
        job.getConfiguration().set(TableOutputFormat.OUTPUT_TABLE, HBASE_TABLE_NAME);
        job.setNumReduceTasks(10);
        FileInputFormat.addInputPath(job, new Path(otherArgs[0]));
        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }

    public static void createHbaseTable() throws IOException {
        HBaseConfiguration hc = new HBaseConfiguration(new Configuration());
        HTableDescriptor ht = new HTableDescriptor(HBASE_TABLE_NAME);
        ht.addFamily(new HColumnDescriptor(COLUMN_FAMILY));
        HBaseAdmin hba = new HBaseAdmin(hc);
        if (hba.tableExists(HBASE_TABLE_NAME)) {
            hba.disableTable(HBASE_TABLE_NAME);
            hba.deleteTable(HBASE_TABLE_NAME);
        }
        hba.createTable(ht);
        hba.close();
    }
}


//
//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;
//import org.apache.hadoop.conf.Configuration;
//import org.apache.hadoop.fs.Path;
//import org.apache.hadoop.hbase.HBaseConfiguration;
//import org.apache.hadoop.hbase.HColumnDescriptor;
//import org.apache.hadoop.hbase.HTableDescriptor;
//import org.apache.hadoop.hbase.ZooKeeperConnectionException;
//import org.apache.hadoop.hbase.client.HBaseAdmin;
//import org.apache.hadoop.hbase.mapreduce.TableOutputFormat;
//import org.apache.hadoop.io.Writable;
//import org.apache.hadoop.mapreduce.Job;
//import org.apache.hadoop.hbase.client.HTable;
//
//import org.apache.hadoop.mapreduce.Mapper;
//import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
//import org.apache.hadoop.io.Text;
//import org.apache.hadoop.hbase.client.Put;
//import au.com.bytecode.opencsv.CSVParser;
//import org.apache.hadoop.hbase.util.Bytes;
//import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
//import org.apache.hadoop.util.GenericOptionsParser;
//
//import java.io.IOException;
//import java.util.UUID;
//
///**
// * Created by ying on 3/17/17.
// */
//public class HPopulate {
//    private static final Log LOG = LogFactory.getLog(HPopulate.class);
//    public static final String HBASE_TABLE_NAME = "Flights";
//    public static final String COLUMN_FAMILY = "Flight";
//    public static final String COLUMN_AIRLINE = "airline";
//    public static final String COLUMN_MONTH = "month";
//    public static final String COLUMN_DELAY = "delay";
//
//    //Mapper
//    public static class HPopulateMapper extends
//            Mapper<Object, Text, ImmutableBytesWritable, Writable> {
//        private CSVParser csvParser = null;
//        private HTable table = null;
//
//        protected void setup(Context context) throws IOException {
//            csvParser = new CSVParser(',', '"');
//            Configuration config = HBaseConfiguration.create();
//            table = new HTable(config, HBASE_TABLE_NAME);
//            table.setAutoFlush(false);
//            // 100 MB buffer flush size
//            table.setWriteBufferSize(102400);
//
//        }
//
//        public void map(Object offset, Text value, Context context)
//                throws IOException, InterruptedException {
//            String[] vals = csvParser.parseLine(value.toString());
//
//            if (vals.length == 0) {
//                return;
//            }
//            StringBuilder rowKey = new StringBuilder();
//            rowKey.append(vals[0]).append("#").append(vals[41]).append("#").append(vals[43]).append("#").append(UUID
//                    .randomUUID());
//
//            String airline = vals[6].trim();
//            String month = vals[2].trim();
//            String delay = vals[37].trim();
//            Put put = new Put(Bytes.toBytes(rowKey.toString()));
//            put.add(COLUMN_FAMILY.getBytes(), COLUMN_AIRLINE.getBytes(), airline.getBytes());
//            put.add(COLUMN_FAMILY.getBytes(), COLUMN_MONTH.getBytes(), month.getBytes());
//            put.add(COLUMN_FAMILY.getBytes(), COLUMN_DELAY.getBytes(), delay.getBytes());
//            LOG.info("Put into Hbase" + put.toString());
//            table.put(put);
//
//        }
//
//        protected void cleanup(Context context) throws IOException, InterruptedException {
//            table.close();
//        }
//    }
//
//    public static void main(String[] args) throws IOException, InterruptedException, ClassNotFoundException {
//        Configuration conf = new Configuration();
//        String[] otherArgs = new GenericOptionsParser(conf, args)
//                .getRemainingArgs();
//        if (otherArgs.length != 1) {
//            System.err.println("Usage: H-POPULATE <in>");
//            System.exit(2);
//        }
//
//        // Create table for HBase
//        createHbaseTable();
//
//        // Configure job
//        Job job = new Job(conf, "H-Populate");
//        job.setJarByClass(HPopulate.class);
//        job.setMapperClass(HPopulateMapper.class);
//        job.setOutputKeyClass(ImmutableBytesWritable.class);
//        job.setOutputValueClass(Put.class);
//        job.setOutputFormatClass(TableOutputFormat.class);
//        job.getConfiguration().set(TableOutputFormat.OUTPUT_TABLE, HBASE_TABLE_NAME);
//        // set partitioner to 0 explicitly as not required
//        job.setNumReduceTasks(10);
//        FileInputFormat.addInputPath(job, new Path(otherArgs[0]));
////        FileOutputFormat.setOutputPath(job, new Path(otherArgs[1]));
//        System.exit(job.waitForCompletion(true) ? 0 : 1);
//    }
//
//    /**
//     * Connects to the HBase instance and creates table. If table already exists then
//     * it deletes the existing table and creates again
//     *
//     * @throws IOException
//     * @throws ZooKeeperConnectionException
//     */
//    public static void createHbaseTable() throws IOException, ZooKeeperConnectionException {
//        HBaseConfiguration hc = new HBaseConfiguration(new Configuration());
//        HTableDescriptor ht = new HTableDescriptor(HBASE_TABLE_NAME);
//        ht.addFamily(new HColumnDescriptor(COLUMN_FAMILY));
//        HBaseAdmin hba = new HBaseAdmin(hc);
//        if (hba.tableExists(HBASE_TABLE_NAME)) {
//            hba.disableTable(HBASE_TABLE_NAME);
//            hba.deleteTable(HBASE_TABLE_NAME);
//        }
//        hba.createTable(ht);
//        hba.close();
//    }
//}

