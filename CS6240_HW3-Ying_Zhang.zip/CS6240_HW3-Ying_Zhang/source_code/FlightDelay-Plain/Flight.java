package FlightDelay;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

/**
 * Created by ying on 2/24/17.
 */
public class Flight implements Writable {
    private Text flightDate;
    private IntWritable depTime;
    private IntWritable arrTime;
    private IntWritable arrDelayMinutes;
    private Text leg;

    public Flight() {
        this.flightDate = new Text();
        this.depTime = new IntWritable();
        this.arrTime = new IntWritable();
        this.arrDelayMinutes = new IntWritable();
        this.leg = new Text();
    }

    public Flight(Text flightDate, IntWritable depTime,
                  IntWritable arrTime, IntWritable arrDelayMinutes) {
        this.flightDate = flightDate;
        this.depTime = depTime;
        this.arrTime = arrTime;
        this.arrDelayMinutes = arrDelayMinutes;
    }

    public Text getFlightDate() {
        return flightDate;
    }

    public IntWritable getDepTime() {
        return depTime;
    }

    public IntWritable getArrTime() {
        return arrTime;
    }

    public IntWritable getArrDelayMinutes() {
        return arrDelayMinutes;
    }

    public Text getLeg() {
        return leg;
    }

    public void setLeg(Text leg) {
        this.leg = leg;
    }

    public void write(DataOutput dataOutput) throws IOException {
        flightDate.write(dataOutput);
        depTime.write(dataOutput);
        arrTime.write(dataOutput);
        arrDelayMinutes.write(dataOutput);
        leg.write(dataOutput);
    }

    public void readFields(DataInput dataInput) throws IOException {
        flightDate.readFields(dataInput);
        depTime.readFields(dataInput);
        arrTime.readFields(dataInput);
        arrDelayMinutes.readFields(dataInput);
        leg.readFields(dataInput);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Flight flight = (Flight) o;

        if (!flightDate.equals(flight.flightDate)) return false;
        if (!depTime.equals(flight.depTime)) return false;
        if (!arrTime.equals(flight.arrTime)) return false;
        if (!arrDelayMinutes.equals(flight.arrDelayMinutes)) return false;
        return leg.equals(flight.leg);

    }

    @Override
    public int hashCode() {
        int result = flightDate.hashCode();
        result = 31 * result + depTime.hashCode();
        result = 31 * result + arrTime.hashCode();
        result = 31 * result + arrDelayMinutes.hashCode();
        result = 31 * result + leg.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "Flight{" +
                "flightDate=" + flightDate +
                ", depTime=" + depTime +
                ", arrTime=" + arrTime +
                ", arrDelayMinutes=" + arrDelayMinutes +
                ", leg=" + leg +
                '}';
    }
}
