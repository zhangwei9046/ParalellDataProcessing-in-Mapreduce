package FlightDelay;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

import java.io.*;
import java.util.ArrayList;
import java.util.List;


/**
 * Created by ying on 2/23/17.
 */
public class FlightDelay {
    public enum Counters {
        SUM,
        COUNT
    }

    //Mapper
    public static class FlightClassifyMapper
            extends Mapper<Object, Text, Text, Flight> {
        public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            // Read attributes from the line of flight record
            // Get year, month and flightDate of the flight
            String[] attributes = value.toString().split(",");
            int year = Integer.parseInt(attributes[0]);
            int month = Integer.parseInt(attributes[2]);
            String flightDate = attributes[5];
            // If flight is not in the time period required, return
            if (year < 2007 || year == 2007 && month < 6 || year == 2008 && month > 5 || year > 2008) {
                return;
            }

            // Get cancelled & diverted attributes from the flight
            boolean cancelled = (int) Float.parseFloat(attributes[43]) == 1;
            boolean diverted = (int) Float.parseFloat(attributes[45]) == 1;
            // If flight has been cancelled or diverted, return
            if (cancelled || diverted) {
                return;
            }

            // Get origin & destination from the flight
            String origin = attributes[11].substring(1, 4);
            String dest = attributes[18].substring(1, 4);
            // If flight is not from ORD or to JFK, return
            if (!(origin.equals("ORD") && !dest.equals("JFK")) && !(!origin.equals("ORD") && dest.equals("JFK"))) {
                return;
            }

            // Get "departure time", "arrival time" & "arrival delay minutes" from the flight
            int depTime = Integer.parseInt(attributes[26].substring(1, attributes[26].length() - 1));
            int arrTime = Integer.parseInt(attributes[37].substring(1, attributes[37].length() - 1));
            int arrDelayMinutes = (int) Float.parseFloat(attributes[39]);

            // Construct a Writable Flight Object
            // If it's from ORD, set its "leg" to "F1"
            // If it's to JFK, set its "leg" to "F2"
            Flight flight = new Flight(new Text(flightDate), new IntWritable(depTime),
                    new IntWritable(arrTime), new IntWritable(arrDelayMinutes));
            flight.setLeg(origin.equals("ORD") && !dest.equals("JFK") ? new Text("F1") : new Text("F2"));

            // F1: Emit (dest, flight)
            // F2: Emit (origin, flight)
            if (flight.getLeg().toString().equals("F1")) {
                context.write(new Text(dest), flight);
            } else {
                context.write(new Text(origin), flight);
            }
        }

    }


    //Reducer
    public static class FlightJoinReducer extends Reducer<Text, Flight, Text, IntWritable> {
        private IntWritable result = new IntWritable();

        public void reduce(Text key, Iterable<Flight> values, Context context)
                throws IOException, InterruptedException {
            List<Flight> f1s = new ArrayList<Flight>();
            List<Flight> f2s = new ArrayList<Flight>();
            // Separate the incoming values into "F1" or "F2"
            for (Flight flight : values) {
                String flightDate = flight.getFlightDate().toString();
                int depTime = flight.getDepTime().get();
                int arrTime = flight.getArrTime().get();
                int arrDelayMinutes = flight.getArrDelayMinutes().get();
                String leg = flight.getLeg().toString();
                if (leg.equals("F1")) {
                    Flight f = new Flight(new Text(flightDate), new IntWritable(depTime),
                            new IntWritable(arrTime), new IntWritable(arrDelayMinutes));
                    f.setLeg(new Text(leg));
                    f1s.add(f);
                } else {
                    Flight f = new Flight(new Text(flightDate), new IntWritable(depTime),
                            new IntWritable(arrTime), new IntWritable(arrDelayMinutes));
                    f.setLeg(new Text(leg));
                    f2s.add(f);
                }
            }

            // For each flight of "F1", do join with each flight of "F2"
            // If the two-leg flight is qualified, add delay sum and count to global counter
            int sum = 0, count = 0;
            for (Flight f1 : f1s) {
                for (Flight f2 : f2s) {
                    if (f1.getFlightDate().equals(f2.getFlightDate()) &&
                            f1.getArrTime().get() < f2.getDepTime().get()) {
                        int delay = f1.getArrDelayMinutes().get() + f2.getArrDelayMinutes().get();
                        count++;
                        sum += delay;
                        result.set(delay);
                        context.write(new Text("Delay"), result);
                    }
                }
            }
            context.getCounter(Counters.SUM).increment(sum);
            context.getCounter(Counters.COUNT).increment(count);
        }
    }


    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();
        if (otherArgs.length != 2) {
            System.err.println("Usage: flightdelay <in> <out>");
            System.exit(2);
        }

        //Run Flight Delay Map-Reduce Job
        Job job1 = new Job(conf, "flight delay");
        job1.setJarByClass(FlightDelay.class);
        job1.setMapperClass(FlightDelay.FlightClassifyMapper.class);
        job1.setReducerClass(FlightDelay.FlightJoinReducer.class);
        job1.setMapOutputKeyClass(Text.class);
        job1.setMapOutputValueClass(Flight.class);
        // Set Reducer Tasks to 10
        job1.setNumReduceTasks(10);
        FileInputFormat.addInputPath(job1, new Path(otherArgs[0]));
        FileOutputFormat.setOutputPath(job1, new Path(otherArgs[1]));
        job1.waitForCompletion(true);

        if (job1.isSuccessful()) {
            long sum = job1.getCounters().findCounter(Counters.SUM).getValue();
            long count = job1.getCounters().findCounter(Counters.COUNT).getValue();
            double avg = (double) sum / count;
            System.out.println("Delay Average: " + avg);
            System.exit(0);
        } else {
            System.out.println("Job " + job1.getJobName() + " Failed!");
            System.exit(1);
        }
    }
}